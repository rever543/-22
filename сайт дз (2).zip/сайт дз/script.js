const языки = {};

// Загрузка данных из JSON
async function loadLanguages() {
    try {
        const response = await fetch('languages.json');
        const data = await response.json();
        
        // Преобразуем массив в объект для совместимости с существующим кодом
        data.languages.forEach(function(lang) {
            языки[lang.name] = {
                guide: lang.guide,
                links: lang.links
            };
        });
        
        // Создаем элементы языков в HTML
        renderLanguages(data.languages);
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        document.getElementById('languages-list').innerHTML = '<p style="color: red;">Ошибка загрузки данных о языках</p>';
    }
}

// Динамическое создание элементов языков
function renderLanguages(languages) {
    const list = document.getElementById('languages-list');
    list.innerHTML = '';
    
    languages.forEach(function(lang) {
        const div = document.createElement('div');
        div.className = 'a2';
        div.setAttribute('data-name', lang.name);
        div.onclick = function() { showGuide(lang.name); };
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'a4';
        nameDiv.textContent = lang.name;
        
        const descDiv = document.createElement('div');
        descDiv.className = 'a5';
        descDiv.textContent = lang.description;
        
        const btn = document.createElement('button');
        btn.className = 'a6';
        btn.textContent = 'Добавить в избранное';
        btn.onclick = function(e) {
            e.stopPropagation();
            addToFavorites(lang.name, lang.description);
        };
        
        div.appendChild(nameDiv);
        div.appendChild(descDiv);
        div.appendChild(btn);
        list.appendChild(div);
    });
}

function showGuide(languageName) {
    const guide = языки[languageName];
    if (!guide) return;
    
    document.getElementById('modal-title').textContent = languageName;
    document.getElementById('modal-guide').innerHTML = guide.guide;
    
    let linksHtml = '<p>Полезные ссылки для изучения:</p><ul>';
    guide.links.forEach(function(link) {
        linksHtml += '<li><a href="' + link.url + '" target="_blank">' + link.name + '</a></li>';
    });
    linksHtml += '</ul>';
    document.getElementById('modal-links').innerHTML = linksHtml;
    
    document.getElementById('modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function loadFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const list = document.getElementById('favorites-list');
    list.innerHTML = '';
    
    if (favorites.length === 0) {
        list.innerHTML = '<p style="color: #999;">Пока нет избранных языков</p>';
        return;
    }
    
    favorites.forEach(function(item) {
        if (!item || !item.name) return;
        
        const div = document.createElement('div');
        div.className = 'a2 a3';
        div.style.cursor = 'pointer';
        div.onclick = function() { showGuide(item.name); };
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'a4';
        nameDiv.textContent = item.name;
        
        const descDiv = document.createElement('div');
        descDiv.className = 'a5';
        descDiv.textContent = item.description || '';
        
        const btn = document.createElement('button');
        btn.className = 'a6 a7';
        btn.textContent = 'Удалить из избранного';
        btn.onclick = function(e) { e.stopPropagation(); removeFromFavorites(item.name); };
        
        div.appendChild(nameDiv);
        div.appendChild(descDiv);
        div.appendChild(btn);
        list.appendChild(div);
    });
}

function addToFavorites(name, description) {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    
    if (!favorites.find(function(item) { return item && item.name === name; })) {
        favorites.push({name: name, description: description});
        localStorage.setItem('favorites', JSON.stringify(favorites));
        loadFavorites();
    }
}

function removeFromFavorites(name) {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    favorites = favorites.filter(function(item) { return item && item.name !== name; });
    localStorage.setItem('favorites', JSON.stringify(favorites));
    loadFavorites();
}

// Инициализация при загрузке страницы
loadLanguages();
loadFavorites();
